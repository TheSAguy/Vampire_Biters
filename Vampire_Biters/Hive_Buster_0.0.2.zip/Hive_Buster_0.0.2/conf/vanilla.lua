local SWVar = SWVariables
-------------------------------------------------------------- Prototypes ----------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------- Artillery -----------------------------------------------------------------------------
--[[
--Hive Buster
SWVar.arty_mk4 = {}
local arty_mk4 = SWVar.arty_mk4

--arty_mk4.minable = {mining_time = 5, result = "Hive_Buster_Area"}
arty_mk4.stack_size = 1
arty_mk4.recipe = {}
arty_mk4.recipe.energy_required = 240
arty_mk4.recipe.ingredients = {{"fusion-reactor-equipment", 5}, {"steel-plate", 200}, {"battery-mk2-equipment", 10}, {"processing-unit", 100}}
------------------------------------------------------------------------------------------------------------------------------------------------------

----Hive Buster Ammo
SWVar.heshell_mk4 = {}
local heshell_mk4 = SWVar.heshell_mk4
heshell_mk4.stack_size = 50
--heshell_mk4.acceleration = 0.0005
heshell_mk4.perimeter = 30
heshell_mk4.damage = 
{
	type = "damage",
	damage = {amount = 150, type = "explosion"}
}
heshell_mk4.recipe = {}
heshell_mk4.recipe.energy_required = 5
heshell_mk4.recipe.ingredients = 
heshell_mk4.recipe.count = 2


------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------- Technology -----------------------------------------------------------------------------
SWVar.technology = {}
--Advanced Rocketry
SWVar.technology.advanced_rocketry = {}
local advanced_rocketry = SWVar.technology.advanced_rocketry
advanced_rocketry.count = 300
advanced_rocketry.ingredients =
{
	{"science-pack-1", 1},
	{"science-pack-2", 1}
}
advanced_rocketry.time = 30
advanced_rocketry.prerequisites = {"military-2", "rocketry"}

--Artillery
SWVar.technology.artillery = {}
local tech_artillery = SWVar.technology.artillery
tech_artillery.count = 200
tech_artillery.ingredients =
{
	{"science-pack-1", 2},
	{"science-pack-2", 2},
	{"science-pack-3", 1}
}
tech_artillery.time = 30
tech_artillery.prerequisites = {"advanced-rocketry"}
]]