--Functions
function fireArty(arty,target,distance,missile)


	arty.surface.create_entity({name=missile, position = {x = arty.position.x, y = arty.position.y +1}, force = game.forces.player, target = target, speed= 0.1})
	--arty.surface.create_entity({name=missile, position = {x = arty.position.x, y = arty.position.y}, force = arty.force, target = target, speed= 0.1})
	arty.surface.pollute(arty.position,100) -- The firing of the Artillery causes Pollution
	
end


--Artillery
function processArty(artyList)
	
	local arty=artyList[1]
	local artyi=artyList[2]
	local inventory = artyi.get_inventory(1)
	local inventoryContent = inventory.get_contents()
	local rocketTyp
	local ammo = 0
	local spawner
	local target

	
	if inventoryContent ~= nil then
		for n,a in pairs(inventoryContent) do
			rocketTyp=n
			ammo=a
		end
	end
	
	if ammo > 0 then	

			spawner = arty.surface.find_entities_filtered({area = {{x = arty.position.x - 50, y = arty.position.y - 50}, {x = arty.position.x + 50, y = arty.position.y + 50}}, type = "unit-spawner"})

			--CheckSpawners
			if #spawner > 0 and target == nil then
				for _,enemy in pairs(spawner) do
					local distance = math.sqrt(((arty.position.x - enemy.position.x)^2) +((arty.position.y - enemy.position.y)^2) )
					if (distance > 10) then
						if target == nil then
							target={enemy,distance}
						else
							if target[2] > distance then
								target[1]=enemy
								target[2]=distance
							end
						end
					end
				end
			end


		--Attack!?
		if target ~= nil then
			fireArty(arty,target[1],target[2],rocketTyp)

			--reduce Ammo
			ammo = ammo-1
			inventory.clear()
			if ammo > 0 then
				inventory.insert({name = rocketTyp, count = ammo})
			end
			--Cooldown
			artyList[3]=20
		end
	end
end