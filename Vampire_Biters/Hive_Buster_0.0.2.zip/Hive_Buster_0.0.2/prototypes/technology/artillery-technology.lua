data:extend({
	{
		type = "technology",
		name = "artillery",
		icon = "__Hive_Buster__/graphics/technology/advanced-rocketry.png",
		effects = 
		{
			{
				type = "unlock-recipe",
				recipe = "Hive_Buster"
			},
			{
				type = "unlock-recipe",
				recipe = "Hive_Buster_Ammo"
			},

		},
		prerequisites = {"military-2", "rocketry"},
		unit = 
		{
			count = 200,
			ingredients =
			{
				{"science-pack-1", 2},
				{"science-pack-2", 2},
				{"science-pack-3", 1}
			},
			time = 30,
		}
	},
	
})
