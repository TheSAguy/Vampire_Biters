data:extend({

-- Artillery MK4
 {
    type = "recipe",
    name = "Hive_Buster",
    enabled = "false",
	energy_required = 50,
	ingredients = {{"processing-unit", 5},{"electric-engine-unit", 5}, {"explosive-rocket", 5}},
    result = "Hive_Buster_Area"
 },
})