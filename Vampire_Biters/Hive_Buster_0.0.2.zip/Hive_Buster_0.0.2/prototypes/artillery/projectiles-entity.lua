require "util"
data:extend({
	--Projectile

 -- Have Buster Ammo
  {
    type = "projectile",
    name = "Hive_Buster_Ammo",
    flags = {"not-on-map"},
    acceleration = 0.0005,
	action =
	{
		{
			type = "area",
			perimeter = 10,
			action_delivery =
			{
				type = "instant",
				target_effects =
				{
					{
					type = "damage",
					damage = {amount = 100, type = "physical"}
					},
					{
					type = "damage",
					damage = {amount = 150, type = "explosion"}
					},
				}
			}
		},
		{
			type = "direct",
			action_delivery = 
			{
				type = "instant",
				target_effects =
				{
					{
					type = "create-entity",
					entity_name = "small-scorchmark",
					check_buildability = true
					},
				}
			}
		}
	},
	light = {intensity = 0.8, size = 6},
    animation =
    {
        filename = "__Hive_Buster__/graphics/projectiles/Hive_Buster_Ammo.png",
        priority = "extra-high",
        width = 18,
        height = 47,
        frame_count = 1
    },
    shadow =
    {
        filename = "__Hive_Buster__/graphics/projectiles/Hive_Buster_Ammo-shadow.png",
        priority = "extra-high",
        width = 18,
        height = 47,
        frame_count = 1
    }
  },

})