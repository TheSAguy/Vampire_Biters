require "defines"
require "util"
require "libs/util_ext"
require "scripts/artillery"


local loaded

--[[
function reduceCooldown()
	if global.listArty ~= nil then
		for k,v in pairs(global.listArty) do
			if v[1].valid and v[2].valid then
				v[3]=v[3]-1
				if v[3] <=0 then
					processArty(v)
				end
			else
				if v[1].valid then
					v[1].destroy()
				end
				if v[2].valid then
					v[2].destroy()
				end
				table.remove(global.listArty, k)
				if #global.listArty == 0 then
					global.listArty = nil
				end
			end
		end
	end
end
]]


function reduceCooldown()
	for k,v in pairs(global.listArty) do
		if v[1].valid and v[2].valid then
			v[3]=v[3]-1
			if v[3] <=0 then
				processArty(v)
			end
		end
	end
end

function ticker()
	if global.listArty ~= nil then
		if global.sbticks == 0 or global.sbticks == nil then
			global.sbticks = 60
			reduceCooldown()
		else
			global.sbticks = global.sbticks - 1
		end
	else
		script.on_event(defines.events.on_tick, nil)
	end
end


script.on_load(function()
	if not loaded then
		loaded = true
		if global.listArty ~= nil then
			script.on_event(defines.events.on_tick, ticker)
		end
	end
end)


script.on_init(function()
	loaded = true
	
	if global.listArty ~= nil then
		script.on_event(defines.events.on_tick, ticker)
	end
end)


function On_Built(event)
	local newArty
	local newArtyI
	local artyName
	local entity = event.created_entity
	
	
	if entity.name == "Hive_Buster_Area" then
		artyName="Hive_Buster"
	end
	
	if artyName ~= nil then
		
		local surface = entity.surface
		local force = entity.force
		local position = entity.position
	
		newArty  = surface.create_entity({name = artyName, position = position, direction = event.created_entity.direction, force = force})
		newArtyI = surface.create_entity({name = artyName.."i", position = position, direction = event.created_entity.direction, force = force})
		newArtyR = surface.create_entity({name = artyName.."r", position = position, direction = event.created_entity.direction, force = force})
		
		newArty.health = event.created_entity.health
		newArtyI.health = event.created_entity.health
		newArtyR.health = event.created_entity.health
		
		event.created_entity.destroy()
		
		newArty.destructible = false
		newArty.operable = false
		newArtyI.operable = true
		newArtyR.operable = false
		newArtyR.destructible = false
		
		if global.listArty == nil then
			global.listArty = {}
			script.on_event(defines.events.on_tick, ticker)
		end
		table.insert(global.listArty, {newArty,newArtyI,newArtyR,0})
		group_entities(cantor(position.x,position.y), { newArty, newArtyI, newArtyR })	  
		
	end
end

----------------------------------------------------------------

function On_Remove(event)
    local entity = event.entity
	if entity.name == "Hive_Buster" or entity.name == "Hive_Busteri" or entity.name == "Hive_Busterr" then
	    local pos_hash = cantor(entity.position.x,entity.position.y)
        local entity_group = getGroup_entities(pos_hash)
		if entity_group then
		
            for ix, vx in ipairs(entity_group) do
                if vx == entity then
				
                else
                    vx.destroy()
                end
				table.remove(global.listArty, ix)
				if #global.listArty == 0 then
					global.listArty = nil
				end
            end
			
		end	
		ungroup_entities(pos_hash)
	end
end


function On_Death(event)
    local entity = event.entity
	if entity.name == "Hive_Buster" or entity.name == "Hive_Busteri" or entity.name == "Hive_Busterr" then
	    local pos_hash = cantor(entity.position.x,entity.position.y)
        local entity_group = getGroup_entities(pos_hash)
		if entity_group then
		
            for ix, vx in ipairs(entity_group) do
                if vx == entity then
                    vx.destroy()
                else
                    vx.die()
                end
				table.remove(global.listArty, ix)
				if #global.listArty == 0 then
					global.listArty = nil
				end
            end
			
		end	
		ungroup_entities(pos_hash)
	end
end




script.on_event(defines.events.on_built_entity, On_Built)
script.on_event(defines.events.on_robot_built_entity, On_Built)

script.on_event(defines.events.on_preplayer_mined_item, On_Remove)
script.on_event(defines.events.on_robot_pre_mined, On_Remove)
script.on_event(defines.events.on_entity_died, On_Death)



--- Utils
function group_entities(entity_list)
    return group_entities(nil, entity_list)
end

function group_entities(entity_groupid, entity_list)
    return group("entities", entity_groupid, entity_list)
end

function getGroup_entities(entity_groupid)
    return getGroup("entities", entity_groupid)
end

function getGroup_entities_by_member(entity_id)
    return getGroup_byMember("entities", entity_id)
end

function ungroup_entities(entity_groupid)
    return ungroup("entities", entity_groupid)
end
