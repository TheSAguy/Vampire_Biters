function getArtyAtr(name)
	local atr={}

	if name == "Hive_Buster" then
		atr={
			minrange=10,
			maxrange=50,
			muzzle=true,
			pollution=100,
			aggro=true,
			cooldown=20,
			autofire=true
		}
	end
	return atr
end
