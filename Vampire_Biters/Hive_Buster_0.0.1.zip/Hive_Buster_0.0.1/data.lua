SWConfig = {}
SWVariables = {}
require "config"


---------------------------------------------------------------
------------------------- Load Config -------------------------
---------------------------------------------------------------
require "conf.vanilla"

---------------------------------------------------------------



---------------------------------------------------------------
----------------------- Load Prototypes -----------------------
---------------------------------------------------------------

-- Items Groups
require("prototypes.item-group.core")

-- Artillery
require("prototypes.artillery.artillery-item")
require("prototypes.artillery.artillery-recipe")
require("prototypes.artillery.artillery-entity")
require("prototypes.technology.artillery-technology")

-- Projectiles
require("prototypes.artillery.projectiles-item")
require("prototypes.artillery.projectiles-recipe")
require("prototypes.artillery.projectiles-entity")
require("prototypes.artillery.explosion-entity")


