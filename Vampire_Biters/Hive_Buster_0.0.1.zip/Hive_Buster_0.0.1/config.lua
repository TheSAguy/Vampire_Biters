local SW = SWConfig
---------------------------------------------------------------------------
-------------------------- Change Balance ---------------------------------
---------------------------------------------------------------------------
SW.DyTech = false --to fit DyTechWar (will only work if DyTechWar found)
SW.Custom = false --Custom Config (location: /conf/!custom.lua)
SW.BaseOverride = false
---------------------------------------------------------------------------
------------------------------- Toys --------------------------------------
---------------------------------------------------------------------------
SW.ExtraLoot = false --Extra Loot from Aliens (small-alien-artifact)
SW.SupremeOres = false --Currently only spawns a new resource
SW.newEvilForces = false --Not in the public version of the mod 