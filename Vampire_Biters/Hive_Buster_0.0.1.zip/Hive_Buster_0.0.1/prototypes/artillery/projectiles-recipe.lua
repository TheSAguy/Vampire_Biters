data:extend({

  -- HE Shell MK4
 {
    type= "recipe",
    name= "Hive_Buster_Ammo",
    enabled = "false",
	energy_required = 5,
	ingredients = {{"processing-unit", 5},{"electric-engine-unit", 5}, {"explosive-rocket", 5}},
    result = "Hive_Buster_Ammo",
	result_count = 2,
 },

})