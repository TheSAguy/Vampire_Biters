data:extend({

	
	-- Artillery - Hive Buster
	
		{
	type = "item",
	name = "Hive_Buster_Area",
	icon = "__Hive_Buster__/graphics/entity/icon.png",
	flags = { "goes-to-quickbar" },
	subgroup = "defensive-structure",
	order = "b-b",
	place_result = "Hive_Buster_Area",
	stack_size = 1,
	},
	
})