data:extend({
	{
		type = "technology",
		name = "artillery",
		icon = "__Hive_Buster__/graphics/technology/advanced-rocketry.png",
		effects = 
		{
			{
				type = "unlock-recipe",
				recipe = "Hive_Buster"
			},
			{
				type = "unlock-recipe",
				recipe = "Hive_Buster_Ammo"
			},

		},
		prerequisites = SWVariables.technology.advanced_rocketry.prerequisites,
		unit = 
		{
			count = SWVariables.technology.advanced_rocketry.count,
			ingredients =SWVariables.technology.advanced_rocketry.ingredients,
			time = SWVariables.technology.advanced_rocketry.time
		}
	},
	
})
