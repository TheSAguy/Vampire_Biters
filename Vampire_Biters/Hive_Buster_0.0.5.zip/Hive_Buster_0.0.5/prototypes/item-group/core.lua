
data:extend(
{
--[[
  {
    type = "item-group",
    name = "sb-core",
    order = "d-e",
    inventory_order = "s",
    icon = "__Hive_Buster__/graphics/item-group/core.png"
  },
 
  {
    type = "item-subgroup",
    name = "sb-artillery",
    group = "sb-core",
    order = "02"
  },
  {
    type = "item-subgroup",
    name = "sb-shells",
    group = "sb-core",
    order = "03"
  },
]]
  {
    type = "ammo-category",
    name = "Hive_Buster_Ammo",
    order = "03"
  },
}
)
