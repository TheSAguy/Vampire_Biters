data:extend({

	-- Hive Buster Ammo
	{
		type = "ammo",
		name = "Hive_Buster_Ammo",
		icon = "__Hive_Buster__/graphics/projectiles/Hive_Buster_Ammo_Icon.png",
		flags = { "goes-to-main-inventory" },
		ammo_type =
		{
			category = "Hive_Buster_Ammo",
			target_type = "direction",
			action =
			{
				{
					type = "direct",
					action_delivery =
					{				
						type = "projectile",
						projectile = "Hive_Buster_Ammo",
						starting_speed = 1,
						direction_deviation = 0.8,
						range_deviation = 0.8,
						max_range = 50
					}
				}
			}
		},
		subgroup = "ammo",
		order = "a[Hive_Buster_Ammo]",
		stack_size = 50,
	},

})