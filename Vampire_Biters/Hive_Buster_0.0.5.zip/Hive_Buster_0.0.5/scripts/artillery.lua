

--Artillery
function HiveBuster_Check(HiveBusterList)
	
	local HiveBuster=HiveBusterList[1]
	local HiveBusteri=HiveBusterList[2]
	local inventory = HiveBusteri.get_inventory(1)
	local inventoryContent = inventory.get_contents()
	local rocketTyp
	local ammo = 0
	local spawner
	local target

	
	if inventoryContent ~= nil then
		for n,a in pairs(inventoryContent) do
			rocketTyp=n
			ammo=a
		end
	end
	
	if ammo > 0 and HiveBusterList[3].energy > 0 then	

			spawner = HiveBuster.surface.find_entities_filtered({area = {{x = HiveBuster.position.x - 50, y = HiveBuster.position.y - 50}, {x = HiveBuster.position.x + 50, y = HiveBuster.position.y + 50}}, type = "unit-spawner", force= "enemy"})

			--CheckSpawners
			if #spawner > 0 and target == nil then
				for _,enemy in pairs(spawner) do
					local distance = math.sqrt(((HiveBuster.position.x - enemy.position.x)^2) +((HiveBuster.position.y - enemy.position.y)^2) )
					if (distance > 10) and (distance < 51) then
						if target == nil then
							--target={enemy,distance}
							target={enemy}
						end
					end
				end
			end


		--Attack!?
		if target ~= nil then

			HiveBuster.surface.create_entity({name=rocketTyp, position = {x = HiveBuster.position.x - 0.5, y = HiveBuster.position.y - 4.5}, force = HiveBuster.force, target = target, speed= 0.1})
			--HiveBuster.surface.create_entity({name=rocketTyp, position = {x = HiveBuster.position.x - 0.5, y = HiveBuster.position.y - 4.5}, force = HiveBuster.force, target = target[1], speed= 0.1})
			HiveBuster.surface.pollute(HiveBuster.position,100) -- The firing of the Artillery causes Pollution

			
			--reduce Ammo
			ammo = ammo-1
			inventory.clear()
			if ammo > 0 then
				inventory.insert({name = rocketTyp, count = ammo})
			end
			--Cooldown
			HiveBusterList[4]=20
		end
	end
end